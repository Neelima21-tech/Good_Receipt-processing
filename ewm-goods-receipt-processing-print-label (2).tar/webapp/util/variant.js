sap.ui.define(
    ["sap/m/MessageToast", "sap/ui/core/BusyIndicator"],
    (MessageToast, BusyIndicator) => {
        "use strict";

        return {
            //function to apply variant based on the fetched variant info
            applyData(aData) {
                if (!aData) {
                    console.log("no variant data fetched");
                    return;
                }
                aData.forEach(function (oDataObject) {
                    var oControl = this.oFilterBar.determineControlByName(oDataObject.fieldName, oDataObject.groupName);
                    var oObjectData = JSON.parse(oDataObject.fieldData);
                    if (oControl instanceof sap.m.MultiInput) {
                        oControl.removeAllTokens();
                        if (oDataObject.fieldData) {

                            oObjectData.forEach(function (oFieldData) {

                                var oToken = new sap.m.Token({ text: oFieldData.text, key: oFieldData.key });
                                oToken.addCustomData(new sap.ui.core.CustomData(oFieldData.cond));
                                oControl.addToken(oToken);
                            });
                        }
                    }
                    else if (oControl instanceof sap.m.DateRangeSelection) {
                        oControl.setDateValue(oObjectData.start ? new Date(oObjectData.start) : null);
                        oControl.setSecondDateValue(oObjectData.end ? new Date(oObjectData.end) : null);
                    }
                    else if (oControl instanceof sap.m.Input) {
                        oControl.setValue(oObjectData);
                    }
                    else {
                        oControl.setValue(oObjectData.fieldData);
                    }
                }, this);
            },

            //function for variant management
            fetchData() {

                var aData = this.oFilterBar.getAllFilterItems().map(function (oFilterItem) {
                    var oControl = oFilterItem.getControl();
                    var oValue = "";
                    //read the token value for multiinput value type 
                    if (oControl instanceof sap.m.MultiInput) {
                        oValue = oControl.getTokens().map(function (oToken) {
                            return { text: oToken.getText(), cond: oToken.getAggregation("customData")[0].mProperties, key: oToken.getKey() };

                        });
                    }
                    else if (oControl instanceof sap.m.DateRangeSelection) {
                        oValue = {
                            start: oControl.getDateValue() ? oControl.getDateValue().toISOString() : null,
                            end: oControl.getSecondDateValue() ? oControl.getSecondDateValue().toISOString() : null
                        };
                    }
                    else if (oControl instanceof sap.m.Input) {
                        oValue = oControl.getValue();
                    }
                    else {
                        oValue = oControl.getValue();
                    }
                    //return the group, field name and the selected value
                    return {
                        groupName: oFilterItem.getGroupName(),
                        fieldName: oFilterItem.getName(),
                        fieldData: JSON.stringify(oValue),
                    };
                });


                return aData;
            },
            getFiltersWithValues() {
                var aFiltersWithValue = this.oFilterBar.getFilterGroupItems().filter(function (oFilterGroupItem) {
                    var oControl = oFilterGroupItem.getControl();
                    return oControl && oControl.getValue && oControl.getValue().length > 0;
                });

                return aFiltersWithValue;
            },
        };
    }
);