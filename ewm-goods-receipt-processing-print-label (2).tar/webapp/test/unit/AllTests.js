sap.ui.define([
	"comwlewm/goodreceipt/test/unit/controller/Selection.controller"
], function () {
	"use strict";
});
