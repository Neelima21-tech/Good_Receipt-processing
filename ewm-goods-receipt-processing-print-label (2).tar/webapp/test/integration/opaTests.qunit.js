/* global QUnit */

sap.ui.require(["com/wl/ewm/goodreceipt/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
