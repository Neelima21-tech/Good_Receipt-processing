sap.ui.define([
  "sap/ui/core/mvc/Controller",
  'sap/m/MessageToast',
  "sap/m/SearchField",
  "sap/ui/table/Column",
  "sap/m/Label",
  "sap/m/Text",
  "sap/m/ColumnListItem",
  "sap/m/Token",
  "sap/m/Column",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/ui/model/type/String",
  "sap/m/MessageBox",
  "sap/ui/core/BusyIndicator",
  'sap/m/MessagePopover',
  "sap/ui/core/Fragment",
  'sap/m/MessageItem',
  "sap/ui/comp/smartvariants/PersonalizableInfo"
], (Controller, MessageToast,
  SearchField,
  UIColumn,
  Label,
  Text,
  ColumnListItem,
  Token,
  MColumn,
  Filter,
  FilterOperator,
  TypeString,
  MessageBox, BusyIndicator, MessagePopover, Fragment, MessageItem, PersonalizableInfo) => {
  "use strict";

  return Controller.extend("com.wl.mm.goodreceipt.controller.Selection", {
    onInit() {
      // Get the DatePicker control and set its value to the current date
      var oDatePicker1 = this.getView().byId("idPostDate");
      var oCurrentDate = new Date();
      oDatePicker1.setDateValue(oCurrentDate);

      // Get the current user's ID from the UserInfo service
      var user = sap.ushell.Container.getService("UserInfo").getId();

      // Create a token for the current user with custom data for filtering
      var oToken = new Token({ key: user, text: '=' + user });
      oToken.addCustomData(new sap.ui.core.CustomData({
        key: "range",
        value: {
          exclude: false,
          operation: "EQ",
          keyField: "ReceivedBy",
          value1: user,
          value2: null
        },
        writeToDom: false
      }));

      // Set the token in the MultiInput control for received suggestions
      this.getView().byId("multiInputWithSuggestionsrecived").setTokens([oToken]);

      // Validator function to create tokens with custom data for different fields
      var fnValidator = function (fieldSource) {
        return (args) => {
          var text = args.text;
          var oToken = new Token({ key: text, text: '=' + text });
          oToken.addCustomData(new sap.ui.core.CustomData({
            key: "range",
            value: {
              exclude: false,
              operation: "EQ",
              keyField: fieldSource,
              value1: text,
              value2: null
            },
            writeToDom: false
          }));
          return oToken;
        };
      };

      // Get references to various MultiInput controls
      this._oMultiInputPlant = this.byId("multiInputWithSuggestionsPlant");
      this._oMultiInputPurche = this.byId("multiInputWithSuggestionsPurch");
      this._oMultiInputPrint = this.byId("multiInputWithSuggestionsPrinter");
      this._oMultiInputmaterial = this.byId("multiInputWithSuggestionsmaterial");
      this._oMultiInputreceived = this.byId("multiInputWithSuggestionsrecived");

      // Add validators to the MultiInput controls
      this._oMultiInputPlant.addValidator(fnValidator("Plant"));
      this._oMultiInputPurche.addValidator(fnValidator("Purche"));
      this._oMultiInputPrint.addValidator(fnValidator("Printer"));
      this._oMultiInputreceived.addValidator(fnValidator("ReceivedBy"));

      // Bind functions for variant management
      this.applyData = this.applyData.bind(this);
      this.fetchData = this.fetchData.bind(this);
      this.getFiltersWithValues = this.getFiltersWithValues.bind(this);

      // Initialize SmartVariantManagement and register the FilterBar
      this.oSmartVariantManagement = this.getView().byId("pageVariantId");
      this.oFilterBar = this.getView().byId("filterbar");
      this.oTable = this.getView().byId("reportTable");

      this.oFilterBar.registerFetchData(this.fetchData);
      this.oFilterBar.registerApplyData(this.applyData);
      this.oFilterBar.registerGetFiltersWithValues(this.getFiltersWithValues);

      var oPersInfo = new PersonalizableInfo({
        type: "filterBar",
        keyName: "persistencyKey",
        dataSource: "",
        control: this.oFilterBar
      });
      this.oSmartVariantManagement.addPersonalizableControl(oPersInfo);
      this.oSmartVariantManagement.initialise(function () { }, this.oFilterBar);

      // Get references to labels for expanded and snapped states
      this.oExpandedLabel = this.getView().byId("expandedLabel");
      this.oSnappedLabel = this.getView().byId("snappedLabel");
    },
    _onCtrInputChange: function () {
      // Check if the MultiInput control for Plant has a value or tokens
      var ctrValue = this.byId("multiInputWithSuggestionsPlant").getValue() || this.byId("multiInputWithSuggestionsPlant").getTokens().length > 0;
    },

    onPlantValueHelpRequested: function () {
      // Create a new SearchField for basic search
      this._oBasicPlantSearchField = new SearchField();

      // Load the Plant fragment and set up the dialog
      this.loadFragment({
        name: "com.wl.mm.goodreceipt.fragment.Plant"
      }).then(function (oDialog) {
        var oFilterBar = oDialog.getFilterBar(), oColumnPlant, oColumnName1, oColumnName2;
        this._oVHD = oDialog;

        // Add the dialog as a dependent to the view
        this.getView().addDependent(oDialog);

        // Set key fields for filtering in the Define Conditions Tab
        oDialog.setRangeKeyFields([{
          label: "{i18n>valuehelp_plant}",
          key: "Plant",
          type: "string",
          typeInstance: new TypeString({}, {
            maxLength: 4
          })
        }]);

        // Set Basic Search for FilterBar
        oFilterBar.setFilterBarExpanded(false);
        oFilterBar.setBasicSearch(this._oBasicPlantSearchField);

        // Trigger filter bar search when the basic search is fired
        this._oBasicPlantSearchField.attachSearch(function () {
          oFilterBar.search();
        });

        // Get the table asynchronously and set up columns and bindings
        oDialog.getTableAsync().then(function (oTable) {
          // For Desktop and tablet, the default table is sap.ui.table.Table
          if (oTable.bindRows) {
            // Bind rows to the ODataModel and add columns
            oTable.bindAggregation("rows", {
              path: "/ZPP_CDS_I_PLANT_VH",
              events: {
                dataReceived: function () {
                  oDialog.update();
                }
              }
            });
            oColumnPlant = new UIColumn({ label: new Label({ text: "{i18n>valuehelp_plant}" }), template: new Text({ wrapping: false, text: "{Plant}" }) });
            oColumnPlant.data({
              fieldName: "Plant"
            });
            oColumnName1 = new UIColumn({ label: new Label({ text: "{i18n>valuehelp_name}" }), template: new Text({ wrapping: false, text: "{Name1}" }) });
            oColumnName1.data({
              fieldName: "Name1"
            });
            oColumnName2 = new UIColumn({ label: new Label({ text: "{i18n>valuehelp_name2}" }), template: new Text({ wrapping: false, text: "{Name2}" }) });
            oColumnName2.data({
              fieldName: "Name2"
            });
            oTable.addColumn(oColumnPlant);
            oTable.addColumn(oColumnName1);
            oTable.addColumn(oColumnName2);
          }

          // For Mobile, the default table is sap.m.Table
          if (oTable.bindItems) {
            // Bind items to the ODataModel and add columns
            oTable.bindAggregation("items", {
              path: "/ZPP_CDS_I_PLANT_VH",
              template: new ColumnListItem({
                cells: [new Label({ text: "{Plant}" }), new Label({ text: "{Name1}" }), new Label({ text: "{Name2}" })]
              }),
              events: {
                dataReceived: function () {
                  oDialog.update();
                }
              }
            });
            oTable.addColumn(new MColumn({ header: new Label({ text: "{i18n>valuehelp_plant}" }) }));
            oTable.addColumn(new MColumn({ header: new Label({ text: "{i18n>valuehelp_name}" }) }));
            oTable.addColumn(new MColumn({ header: new Label({ text: "{i18n>valuehelp_name2}" }) }));
          }
          oDialog.update();
        }.bind(this));

        // Set the tokens for the dialog and open it
        oDialog.setTokens(this._oMultiInputPlant.getTokens());
        oDialog.open();
      }.bind(this));
    },
    onValueHelpWithSuggestionsPlantOkPress: function (oEvent) {
      // Get the selected tokens from the event and set them to the MultiInput control
      var aTokens = oEvent.getParameter("tokens");
      this._oMultiInputPlant.setTokens(aTokens);
      // Close the value help dialog
      this._oVHD.close();
    },

    onValueHelpWithSuggestionsPlantCancelPress: function () {
      // Close the value help dialog
      this._oVHD.close();
      // Trigger the input change handler
      this._onCtrInputChange();
      // Optionally, trigger value change handler (commented out)
      // this.onValueChange();
    },

    onValueHelpWithSuggestionsAfterClose: function () {
      // Destroy the value help dialog after it is closed
      this._oVHD.destroy();
    },
    onFilterBarWithSuggestionsSearch: function (oEvent) {
      // Get the search query from the basic search field
      var sSearchQuery = this._oBasicPlantSearchField.getValue(),
        aSelectionSet = oEvent.getParameter("selectionSet");

      // Create filters based on the selection set
      var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
        if (oControl.getValue()) {
          aResult.push(new Filter({
            path: oControl.getName(),
            operator: FilterOperator.Contains,
            value1: oControl.getValue()
          }));
        }
        return aResult;
      }, []);

      // Add a filter for the basic search query
      aFilters.push(new Filter({
        filters: [
          new Filter({ path: "Plant", operator: FilterOperator.Contains, value1: sSearchQuery }),
        ],
        and: false
      }));

      // Apply the filters to the table
      this._filterTable(new Filter({
        filters: aFilters,
        and: true
      }));
    },

    _filterTable: function (oFilter) {
      var oVHD = this._oVHD;
      oVHD.getTableAsync().then(function (oTable) {
        if (oTable.bindRows) {
          oTable.getBinding("rows").filter(oFilter);
        }
        if (oTable.bindItems) {
          oTable.getBinding("items").filter(oFilter);
        }
        oVHD.update();
      });
    },
    onValueHelpWithSuggestionsRequested: function () {
      // Create a new SearchField for basic search
      this._oBasicPlantSearchFieldPO = new SearchField();

      // Load the Purchase Order fragment and set up the dialog
      this.loadFragment({
        name: "com.wl.mm.goodreceipt.fragment.Purche"
      }).then(function (oDialog) {
        var oFilterBar = oDialog.getFilterBar(), oColumnPO, oColumnPurchasOrganization, oColumnItem, oColumntype;
        this._oVHD = oDialog;

        // Add the dialog as a dependent to the view
        this.getView().addDependent(oDialog);

        // Set key fields for filtering in the Define Conditions Tab
        oDialog.setRangeKeyFields([{
          label: "{i18n>valuehelp_PO}",
          key: "PurchaseOrder",
          type: "string",
          typeInstance: new TypeString({}, {
            maxLength: 18
          })
        }]);

        // Set Basic Search for FilterBar
        oFilterBar.setFilterBarExpanded(false);
        oFilterBar.setBasicSearch(this._oBasicPlantSearchFieldPO);

        // Trigger filter bar search when the basic search is fired
        this._oBasicPlantSearchFieldPO.attachSearch(function () {
          oFilterBar.search();
        });

        // Get the table asynchronously and set up columns and bindings
        oDialog.getTableAsync().then(function (oTable) {
          // For Desktop and tablet, the default table is sap.ui.table.Table
          if (oTable.bindRows) {
            // Bind rows to the ODataModel and add columns
            oTable.bindAggregation("rows", {
              path: "/ZPP_CDS_I_PO_VH",
              events: {
                dataReceived: function () {
                  oDialog.update();
                }
              }
            });
            oColumnPO = new UIColumn({ label: new Label({ text: "{i18n>valuehelp_PO}" }), template: new Text({ wrapping: false, text: "{PurchaseOrder}" }) });
            oColumnPO.data({
              fieldName: "PurchaseOrder"
            });
            oColumnPurchasOrganization = new UIColumn({ label: new Label({ text: "{i18n>valuehelppurch_porg}" }), template: new Text({ wrapping: false, text: "{PurchasingOrganization}" }) });
            oColumnPurchasOrganization.data({
              fieldName: "PurchasingOrganization"
            });
            oColumnItem = new UIColumn({ label: new Label({ text: "{i18n>valuehelppurch_item}" }), template: new Text({ wrapping: false, text: "{PurchaseOrderItem}" }) });
            oColumnItem.data({
              fieldName: "PurchaseOrderItem"
            });
            oColumntype = new UIColumn({ label: new Label({ text: "{i18n>valuehelppurch_type}" }), template: new Text({ wrapping: false, text: "{PurchaseOrderType}" }) });
            oColumntype.data({
              fieldName: "PurchaseOrderType"
            });
            oTable.addColumn(oColumnPO);
            oTable.addColumn(oColumnPurchasOrganization);
            oTable.addColumn(oColumnItem);
            oTable.addColumn(oColumntype);
          }

          // For Mobile, the default table is sap.m.Table
          if (oTable.bindItems) {
            // Bind items to the ODataModel and add columns
            oTable.bindAggregation("items", {
              path: "/ZPP_CDS_I_PO_VH",
              template: new ColumnListItem({
                cells: [new Label({ text: "{PurchaseOrder}" }), new Label({ text: "{PurchasingOrganization}" }), new Label({ text: "{PurchaseOrderItem}" }), new Label({ text: "{PurchaseOrderType}" })]
              }),
              events: {
                dataReceived: function () {
                  oDialog.update();
                }
              }
            });
            oTable.addColumn(new MColumn({ header: new Label({ text: "{i18n>valuehelp_PO}" }) }));
            oTable.addColumn(new MColumn({ header: new Label({ text: "{i18n>valuehelppurch_porg}" }) }));
            oTable.addColumn(new MColumn({ header: new Label({ text: "{i18n>valuehelppurch_item}" }) }));
            oTable.addColumn(new MColumn({ header: new Label({ text: "{i18n>valuehelppurch_type}" }) }));
          }
          oDialog.update();
        }.bind(this));

        // Set the tokens for the dialog and open it
        oDialog.setTokens(this._oMultiInputPurche.getTokens());
        oDialog.open();
      }.bind(this));
    },
    onValueHelpWithSuggestionsPOOkPress: function (oEvent) {
      // Get the selected tokens from the event and set them to the MultiInput control
      var aTokens = oEvent.getParameter("tokens");
      this._oMultiInputPurche.setTokens(aTokens);
      // Close the value help dialog
      this._oVHD.close();
    },

    onValueHelpWithSuggestionsPOCancelPress: function () {
      // Close the value help dialog
      this._oVHD.close();
    },

    onValueHelpWithSuggestionsPOAfterClose: function () {
      // Destroy the value help dialog after it is closed
      this._oVHD.destroy();
    },

    onFilterBarWithSuggestionsSearchPO: function (oEvent) {
      // Get the search query from the basic search field
      var sSearchQuery = this._oBasicPlantSearchFieldPO.getValue(),
        aSelectionSet = oEvent.getParameter("selectionSet");

      // Create filters based on the selection set
      var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
        if (oControl.getValue()) {
          aResult.push(new Filter({
            path: oControl.getName(),
            operator: FilterOperator.Contains,
            value1: oControl.getValue()
          }));
        }
        return aResult;
      }, []);

      // Add a filter for the basic search query
      aFilters.push(new Filter({
        filters: [
          new Filter({ path: "PurchaseOrder", operator: FilterOperator.Contains, value1: sSearchQuery }),
        ],
        and: false
      }));

      // Apply the filters to the table
      this._filterTablePO(new Filter({
        filters: aFilters,
        and: true
      }));
    },
    _filterTablePO: function (oFilter) {
      var oVHD = this._oVHD;
      // Get the table asynchronously and apply the filter
      oVHD.getTableAsync().then(function (oTable) {
        if (oTable.bindRows) {
          oTable.getBinding("rows").filter(oFilter);
        }
        if (oTable.bindItems) {
          oTable.getBinding("items").filter(oFilter);
        }
        // Update the dialog after filtering
        oVHD.update();
      });
    },

    onValueHelpPrintSuggestionsRequested: function () {
      // Create a new SearchField for basic search
      this._oBasicPrintSearchField = new SearchField();

      // Load the Printer fragment and set up the dialog
      this.loadFragment({
        name: "com.wl.mm.goodreceipt.fragment.Printer"
      }).then(function (oDialog) {
        var oFilterBar = oDialog.getFilterBar(), oColumnPrint, oColumnPlant, oColumnPD;
        this._oVHD = oDialog;

        // Add the dialog as a dependent to the view
        this.getView().addDependent(oDialog);

        // Set key fields for filtering in the Define Conditions Tab
        oDialog.setRangeKeyFields([{
          label: "{i18n>valuehelpprinter_print}",
          key: "Printer",
          type: "string",
          typeInstance: new TypeString({}, {
            maxLength: 18
          })
        }]);

        // Set Basic Search for FilterBar
        oFilterBar.setFilterBarExpanded(false);
        oFilterBar.setBasicSearch(this._oBasicPrintSearchField);

        // Trigger filter bar search when the basic search is fired
        this._oBasicPrintSearchField.attachSearch(function () {
          oFilterBar.search();
        });

        // Get the table asynchronously and set up columns and bindings
        oDialog.getTableAsync().then(function (oTable) {
          // For Desktop and tablet, the default table is sap.ui.table.Table
          if (oTable.bindRows) {
            // Bind rows to the ODataModel and add columns
            oTable.bindAggregation("rows", {
              path: "/ZZ1_ZPP_CBO_PRINTER_DETAIL",
              events: {
                dataReceived: function () {
                  oDialog.update();
                }
              }
            });
            oColumnPrint = new UIColumn({ label: new Label({ text: "{i18n>valuehelpprinter_print}" }), template: new Text({ wrapping: false, text: "{Printer}" }) });
            oColumnPrint.data({
              fieldName: "Printer"
            });
            oColumnPlant = new UIColumn({ label: new Label({ text: "{i18n>valuehelp_plant}" }), template: new Text({ wrapping: false, text: "{Plant}" }) });
            oColumnPlant.data({
              fieldName: "Plant"
            });
            oColumnPD = new UIColumn({ label: new Label({ text: "{i18n>valuehelpprinter_PrinterDes}" }), template: new Text({ wrapping: false, text: "{PrinterDescription}" }) });
            oColumnPD.data({
              fieldName: "PrinterDescription"
            });
            oTable.addColumn(oColumnPrint);
            oTable.addColumn(oColumnPlant);
            oTable.addColumn(oColumnPD);
          }

          // For Mobile, the default table is sap.m.Table
          if (oTable.bindItems) {
            // Bind items to the ODataModel and add columns
            oTable.bindAggregation("items", {
              path: "/ZZ1_ZPP_CBO_PRINTER_DETAIL",
              template: new ColumnListItem({
                cells: [new Label({ text: "{Printer}" }), new Label({ text: "{Plant}" }), new Label({ text: "{PrinterDescription}" })]
              }),
              events: {
                dataReceived: function () {
                  oDialog.update();
                }
              }
            });
            oTable.addColumn(new MColumn({ header: new Label({ text: "{i18n>valuehelpprinter_print}" }) }));
            oTable.addColumn(new MColumn({ header: new Label({ text: "{i18n>valuehelp_plant}" }) }));
            oTable.addColumn(new MColumn({ header: new Label({ text: "{i18n>valuehelpprinter_PrinterDes}" }) }));
          }
          oDialog.update();
        }.bind(this));

        // Set the tokens for the dialog and open it
        oDialog.setTokens(this._oMultiInputPrint.getTokens());
        oDialog.open();
      }.bind(this));
    },
    onValueHelpWithSuggestionsPrintinterOkPress: function (oEvent) {
      // Get the selected tokens from the event and set them to the MultiInput control
      var aTokens = oEvent.getParameter("tokens");
      this._oMultiInputPrint.setTokens(aTokens);
      // Close the value help dialog
      this._oVHD.close();
    },

    onValueHelpWithSuggestionsPinterCancelPress: function () {
      // Close the value help dialog
      this._oVHD.close();
    },

    onValueHelpWithSuggestionsPinterAfterClose: function () {
      // Destroy the value help dialog after it is closed
      this._oVHD.destroy();
    },

    onFilterBarWithSuggestionsSearchPinter: function (oEvent) {
      // Get the search query from the basic search field
      var sSearchQuery = this._oBasicPrintSearchField.getValue(),
        aSelectionSet = oEvent.getParameter("selectionSet");

      // Create filters based on the selection set
      var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
        if (oControl.getValue()) {
          aResult.push(new Filter({
            path: oControl.getName(),
            operator: FilterOperator.Contains,
            value1: oControl.getValue()
          }));
        }
        return aResult;
      }, []);

      // Add a filter for the basic search query
      aFilters.push(new Filter({
        filters: [
          new Filter({ path: "Printer", operator: FilterOperator.Contains, value1: sSearchQuery }),
        ],
        and: false
      }));

      // Apply the filters to the table
      this._filterPrinterTable(new Filter({
        filters: aFilters,
        and: true
      }));
    },

    _filterPrinterTable: function (oFilter) {
      var oVHD = this._oVHD;
      // Get the table asynchronously and apply the filter
      oVHD.getTableAsync().then(function (oTable) {
        if (oTable.bindRows) {
          oTable.getBinding("rows").filter(oFilter);
        }
        if (oTable.bindItems) {
          oTable.getBinding("items").filter(oFilter);
        }
        // Update the dialog after filtering
        oVHD.update();
      });
    },

    formatDate: function (odateString) {
      // Format the date string to "yyyy-MM-dd"
      var sReturnFormattedDate = null;
      if (odateString) {
        var oDateFormatOption = sap.ui.core.format.DateFormat.getDateInstance();
        oDateFormatOption = sap.ui.core.format.DateFormat.getDateInstance({ format: "yyyy-MM-dd", "pattern": "yyyy-MM-dd" });
        sReturnFormattedDate = oDateFormatOption.format(odateString);
      }
      return sReturnFormattedDate;
    },

    onExecutePress: function () {
      // Get values and tokens from various MultiInput controls
      var sPlantValue = this._oMultiInputPlant.getValue(),
        aPlantToken = this._oMultiInputPlant.getTokens(),
        sPrinterValue = this._oMultiInputPrint.getValue(),
        aPrinterToken = this._oMultiInputPrint.getTokens(),
        sPurchesValue = this._oMultiInputPurche.getValue(),
        aPurchesToken = this._oMultiInputPurche.getTokens(),
        sMaterialDoc = this._oMultiInputmaterial.getValue(),
        sPostStart = this.byId("idPostDate").getDateValue(),
        sPostend = this.byId("idPostDate").getSecondDateValue(),
        sReceived = this._oMultiInputreceived.getTokens(),
        aFilter = [];

      // Format the start and end dates
      sPostStart = this.formatDate(sPostStart);
      sPostend = this.formatDate(sPostend);

      // Validation: Ensure the Printer field is filled
      if (!aPrinterToken.length && !sPrinterValue) {
        MessageToast.show("Please fill in the Mandatory field.");
        return; // Stop execution if the validation fails
      }

      // Add plant filters
      if (aPlantToken.length > 0) {
        aPlantToken.forEach(token => {
          var oFilter = this._formFilter(token, "Plant");
          if (oFilter) aFilter.push(oFilter);
        });
      } else if (sPlantValue) {
        aFilter.push(new Filter({
          path: "Plant",
          operator: FilterOperator.EQ,
          value1: sPlantValue.toUpperCase()
        }));
      }

      // Add filters for Received by
      if (sReceived.length > 0) {
        sReceived.forEach(token => {
          var oFilter = this._formFilter(token, "Receivedby");
          if (oFilter) aFilter.push(oFilter);
        });
      }

      // Add filters for Received date if both start and end date exist
      if (sPostStart && sPostend) {
        aFilter.push(new Filter({
          path: "Datereceived",
          operator: FilterOperator.BT,
          value1: sPostStart,
          value2: sPostend
        }));
      }
      // Add filters for Received date if only start date exists
      else if (sPostStart) {
        aFilter.push(new Filter({
          path: "Datereceived",
          operator: FilterOperator.GE,
          value1: sPostStart
        }));
      }

      // Add filters for Material Document
      if (sMaterialDoc) {
        aFilter.push(new Filter({
          path: "MaterialDocument",
          operator: FilterOperator.EQ,
          value1: sMaterialDoc.toUpperCase()
        }));
      }

      // Add filters for Purchase Order
      if (aPurchesToken.length > 0) {
        aPurchesToken.forEach(token => {
          var oFilter = this._formFilter(token, "PurchaseOrder");
          if (oFilter) aFilter.push(oFilter);
        });
      } else if (sPurchesValue) {
        aFilter.push(new Filter({
          path: "PurchaseOrder",
          operator: FilterOperator.EQ,
          value1: sPurchesValue.toUpperCase()
        }));
      }

      // Add filters for Printer
      if (aPrinterToken.length > 0) {
        aPrinterToken.forEach(token => {
          var oFilter = this._formFilter(token, "Printer");
          if (oFilter) aFilter.push(oFilter);
        });
      } else if (sPrinterValue) {
        aFilter.push(new Filter({
          path: "Printer",
          operator: FilterOperator.EQ,
          value1: sPrinterValue.toUpperCase()
        }));
      }

      // Set the filter data to the local model and reset the table
      this.getOwnerComponent().getModel("local").setProperty("/filterData", aFilter);
      this.fnReset();
    },

    _formFilter: function (oToken, sFieldPath) {
      var oFilterObj = {};
      if (oToken.getAggregation("customData") && oToken.getAggregation("customData")[0] && oToken.getAggregation("customData")[0].getProperty("key")) {
        var sKeyType = oToken.getAggregation("customData")[0].getProperty("key");
        switch (sKeyType) {
          case "row": {
            oFilterObj = new Filter({
              path: sFieldPath,
              operator: FilterOperator.EQ,
              value1: oToken.getKey(),
            });
            break;
          }
          case "range": {
            var oValue = oToken.getAggregation("customData")[0].getProperty("value");
            oFilterObj = new Filter({
              path: sFieldPath,
              operator: FilterOperator[oValue.operation],
              value1: oValue.value1,
              value2: oValue.value2
            });
            break;
          }
        }
      }
      // Token added through validator
      else {
        oFilterObj = new Filter({
          path: sFieldPath,
          operator: FilterOperator.EQ,
          value1: oToken.getKey()
        });
      }
      return oFilterObj;
    },

    fnReset: function (oEvent) {
      // Reset the SmartTable entity set and rebind the table
      var oReportTable = this.getView().byId("_IDGenSmartTable");
      oReportTable.setEntitySet("ZPP_CDS_I_GR_Label");
      oReportTable.rebindTable();
    },

    onBeforeRebindTable: function (oEvent) {
      // Add filters to the binding parameters before rebinding the table
      var binding = oEvent.getParameter("bindingParams");
      var aFilter = this.getView().getModel("local").getProperty("/filterData");
      if (aFilter) {
        aFilter.forEach(function (el) {
          binding.filters.push(el);
        });
      }
    },
    onPrint: function (oEvent) {
      // Get the full button ID and extract the button ID
      var oFullButtonId = oEvent.getSource().getId();
      var oButtonID = oFullButtonId.split("--").pop();
      // Determine the print type based on the button ID
      var sPrintType = (oButtonID === "IDPrintBarBtn") ? "true" : "false";
      var payload = [];
      var sTable = this.getView().byId("reportTable");
      var sIndex = this.getView().byId("reportTable").getSelectedIndex();
      // Check if a row is selected in the table
      if (sIndex === -1) {
        var oResourceModel = this.getView().getModel("i18n"),
          oBundle = oResourceModel.getResourceBundle();
        MessageBox.information(oBundle.getText("Print_selectrow"));
        return;
      }
      var oContext = sTable.getContextByIndex(sIndex);
      var oSelectedData = oContext ? oContext.getObject() : null;
      // Check if the selected data has a valid Counter field
      if (!oSelectedData || !oSelectedData.Counter || oSelectedData.Counter.trim() === "") {
        MessageBox.information("Enter Counter Field");
        return;
      }
      var sRow = sTable.getSelectedIndices();
      // Create payload for each selected row
      sRow.forEach(index => {
        var sdata = sTable.getContextByIndex(index).getObject();
        var sPayload = {
          "Plant": sdata.Plant,
          "PurchaseOrder": sdata.PurchaseOrder,
          "Datereceived": sdata.Datereceived,
          "Receivedby": sdata.Receivedby,
          "MaterialDocument": sdata.MaterialDocument,
          "Printer": sdata.Printer,
          "Counter": sdata.Counter,
          "PoLineItem": sdata.PoLineItem,
          "Documentlineitem": sdata.Documentlineitem,
          "Quantity": sdata.Quantity,
          "Unit": sdata.Unit,
          "Description": sdata.Description,
          "Material": sdata.Material,
          "StorageBin": sdata.StorageBin,
          "Vendor": sdata.Vendor,
          "Workorder": sdata.Workorder,
          "StorageLocation": sdata.StorageLocation,
          "nocopies": " ",
          "PrintType": sPrintType
        };
        payload.push(sPayload);
      });
      // Call the function to create print payload
      this.onPrintcreate(payload);
    },

    onPrintcreate: function (finalPayload) {
      var oModel = this.getOwnerComponent().getModel();
      var aDeferredGroups = oModel.getDeferredGroups();
      // Add deferred group if not already present
      if (!aDeferredGroups.includes("gid")) {
        aDeferredGroups = aDeferredGroups.concat(["gid"]);
        oModel.setDeferredGroups(aDeferredGroups);
      }
      BusyIndicator.show();
      // Create entries in the model for each payload
      finalPayload.forEach(function (payload, idx) {
        oModel.create("/ZPP_CDS_I_GR_Label", payload, {
          groupId: "gid",
          success: function (oData, oHdr) {
            // console.log("success-create");
          }.bind(this),
          error: function (oResponse, oHdr) {
            // console.log("error-create");
          }.bind(this),
        });
      }.bind(this));
      // Submit changes to the model
      oModel.submitChanges({
        groupId: "gid",
        success: function (oData) {
          var a = oData.__batchResponses[0].response.body;
          this.printdata(oData);
          this.getOwnerComponent().getModel("local").setProperty("/logVisible", true);
          var oResourceModel = this.getView().getModel("i18n"),
            oBundle = oResourceModel.getResourceBundle();
          MessageBox.information(oBundle.getText("print_logs"));
          BusyIndicator.hide();
        }.bind(this),
        error: function (oError) {
          var oResourceModel = this.getView().getModel("i18n"),
            oBundle = oResourceModel.getResourceBundle();
          MessageBox.information(oBundle.getText("Print_errorreprint"));
        }.bind(this)
      });
    },
    printdata: function (oData) {
      var data = [];
      // Check if the batch responses contain data
      if (oData && oData.__batchResponses && oData.__batchResponses.length > 0) {
        var oMessage = oData.__batchResponses[0].response.body;
        if (oMessage) {
          // Create a message object based on the response
          var sData = {
            title: oMessage,
            type: oMessage.includes("Error") ? "Error" : "Success"
          };
          data.push(sData);
        }
        // Set the messages data to the local model
        this.getView().getModel("local").setData({ messages: data });
      } else if (oData.__batchResponses.length > 0) {
        this.getView().getModel("local").setData({ messages: data });
      }
    },

    handleMessagePopoverPress: function (oEvent) {
      // Create the MessagePopover if it doesn't exist
      if (!this.oMP) {
        this.createMessagePopover();
      }
      // Toggle the MessagePopover
      this.oMP.toggle(oEvent.getSource());
    },

    createMessagePopover: function () {
      // Initialize the MessagePopover with items from the local model
      this.oMP = new MessagePopover({
        items: {
          path: "local>/messages",
          template: new MessageItem({
            title: "{local>title}",
            type: "{local>type}"
          })
        },
        groupItems: true
      });
      // Add the MessagePopover as a dependent to the view
      this.getView().addDependent(this.oMP);
    },

    // Function to set the variant management status to edited when the token values of filter are updated
    onTokenChange: function (oEvent) {
      this._firefilterChange(oEvent);
    },

    // Function to apply variant based on the fetched variant info
    applyData: function (aData) {
      if (!aData) {
        console.log("no variant data fetched");
        return;
      }
      aData.forEach(function (oDataObject) {
        var oControl = this.oFilterBar.determineControlByName(oDataObject.fieldName, oDataObject.groupName);
        var oObjectData = JSON.parse(oDataObject.fieldData);
        if (oControl instanceof sap.m.MultiInput) {
          oControl.removeAllTokens();
          if (oDataObject.fieldData) {
            oObjectData.forEach(function (oFieldData) {
              var oToken = new sap.m.Token({ text: oFieldData.text, key: oFieldData.key });
              oToken.addCustomData(new sap.ui.core.CustomData(oFieldData.cond));
              oControl.addToken(oToken);
            });
          }
        } else if (oControl instanceof sap.m.DateRangeSelection) {
          oControl.setDateValue(oObjectData.start ? new Date(oObjectData.start) : null);
          oControl.setSecondDateValue(oObjectData.end ? new Date(oObjectData.end) : null);
        } else if (oControl instanceof sap.m.Input) {
          oControl.setValue(oObjectData);
        } else {
          oControl.setValue(oObjectData.fieldData);
        }
      }, this);
    },

    // Function for variant management
    fetchData: function () {
      var aData = this.oFilterBar.getAllFilterItems().map(function (oFilterItem) {
        var oControl = oFilterItem.getControl();
        var oValue = "";
        // Read the token value for MultiInput value type
        if (oControl instanceof sap.m.MultiInput) {
          oValue = oControl.getTokens().map(function (oToken) {
            return { text: oToken.getText(), cond: oToken.getAggregation("customData")[0].mProperties, key: oToken.getKey() };
          });
        } else if (oControl instanceof sap.m.DateRangeSelection) {
          oValue = {
            start: oControl.getDateValue() ? oControl.getDateValue().toISOString() : null,
            end: oControl.getSecondDateValue() ? oControl.getSecondDateValue().toISOString() : null
          };
        } else if (oControl instanceof sap.m.Input) {
          oValue = oControl.getValue();
        } else {
          oValue = oControl.getValue();
        }
        // Return the group, field name, and the selected value
        return {
          groupName: oFilterItem.getGroupName(),
          fieldName: oFilterItem.getName(),
          fieldData: JSON.stringify(oValue),
        };
      });
      return aData;
    },

    getFiltersWithValues: function () {
      // Get filters with values from the FilterBar
      var aFiltersWithValue = this.oFilterBar.getFilterGroupItems().filter(function (oFilterGroupItem) {
        var oControl = oFilterGroupItem.getControl();
        return oControl && oControl.getValue && oControl.getValue().length > 0;
      });
      return aFiltersWithValue;
    },

    _updateLabelsAndTable: function () {
      // Update labels and show overlay on the table
      this.oExpandedLabel.setText(this.getFormattedSummaryTextExpanded());
      this.oSnappedLabel.setText(this.getFormattedSummaryText());
      this.oTable.setShowOverlay(true);
    },

    _firefilterChange: function (oEvent) {
      // Set the variant management status to modified and fire filter change event
      this.oSmartVariantManagement.currentVariantSetModified(true);
      this.oFilterBar.fireFilterChange(oEvent);
    },

    onFilterChange: function () {
      // Update labels and table on filter change
      this._updateLabelsAndTable();
    },

    onAfterVariantLoad: function () {
      // Update labels and table after variant load
      this._updateLabelsAndTable();
    },

    getFormattedSummaryText: function () {
      // Get formatted summary text for filters
      var aFiltersWithValues = this.oFilterBar.retrieveFiltersWithValues();
      if (aFiltersWithValues.length === 0) {
        return this._geti18nText("no_filters_active");
      }
      if (aFiltersWithValues.length === 1) {
        return aFiltersWithValues.length + " filter active: " + aFiltersWithValues.join(", ");
      }
      return aFiltersWithValues.length + " filters active: " + aFiltersWithValues.join(", ");
    },

    getFormattedSummaryTextExpanded: function () {
      // Get formatted summary text for expanded filters
      var aFiltersWithValues = this.oFilterBar.retrieveFiltersWithValues();
      if (aFiltersWithValues.length === 0) {
        return this._geti18nText("no_filters_active");
      }
      var sText = aFiltersWithValues.length + " filters active",
        aNonVisibleFiltersWithValues = this.oFilterBar.retrieveNonVisibleFiltersWithValues();
      if (aFiltersWithValues.length === 1) {
        sText = aFiltersWithValues.length + " filter active";
      }
      if (aNonVisibleFiltersWithValues && aNonVisibleFiltersWithValues.length > 0) {
        sText += " (" + aNonVisibleFiltersWithValues.length + " hidden)";
      }
      return sText;
    },

    // Function to fetch the i18n text for the inputted key TEXT and placeholder
    _geti18nText: function (sKeyText, aPlaceholder) {
      var oResourceBundle = this.getOwnerComponent().getModel("i18n");
      var sText = oResourceBundle.getResourceBundle().getText(sKeyText, aPlaceholder);
      return sText;
    }
  });
});
